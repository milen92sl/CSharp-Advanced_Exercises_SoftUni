﻿namespace VetClinic
{
    public class Pet
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Owner { get; set; }

        public Pet(string name, int age, string owner)
        {
            this.Name = name;
            this.Age = age;
            this.Owner = owner;
        }

        public override string ToString()
        {
            return $"{this.Name} {this.Age} ({this.Owner})";
        }
    }
}
